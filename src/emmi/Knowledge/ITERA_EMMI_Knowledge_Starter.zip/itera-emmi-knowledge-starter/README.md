# ITERA EMMI Knowledge Starter

Starter repository structure for EMMI's patient-facing knowledge, prompts, retrieval layer and tool contracts.

## Core principles

1. Runtime patient data beats static knowledge for patient-specific questions.
2. Safety rules beat all other sources.
3. EMMI always uses the patient's active language.
4. EMMI explains and guides; it does not independently diagnose, prescribe, change medication orders, determine eligibility, invent costs, or create legal authority.
5. Keep the master knowledge file as the canonical broad reference while gradually moving stable sections into smaller retrieval documents.

## Recommended source priority

Safety Engine
→ Patient Runtime / Tools
→ Approved ITERA Config
→ Current CMS / Medicare rules
→ Internal ITERA Knowledge
→ Public ITERA Website
→ General model knowledge

## Language map

- EN = English
- ES = Spanish
- KR = Haitian Creole / Kreyòl (never Korean)

## Important

Do not expose the complete knowledge base through the public frontend bundle.
Keep this directory server-side.
