# Patient Experience frontend

The patient-facing web application belongs here.

Do not place the full EMMI knowledge base in `/public`, browser assets, or client-side bundles.
The frontend should call the server-side EMMI service and pass only the minimum context needed for the current interaction.
